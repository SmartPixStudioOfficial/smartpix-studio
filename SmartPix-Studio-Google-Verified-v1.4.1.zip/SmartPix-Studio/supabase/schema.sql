-- SmartPix Studio database foundation for Supabase.
-- Apply this in the Supabase SQL Editor. Never expose the service-role key to the browser.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text check (char_length(display_name) <= 80),
  email text,
  created_at timestamptz not null default now()
);

alter table public.profiles add column if not exists email text;
create unique index if not exists profiles_email_unique_idx on public.profiles(lower(email)) where email is not null;

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null default 'safepay' check (provider in ('stripe','safepay')),
  safepay_reference text,
  safepay_subscription_id text,
  safepay_plan_id text,
  billing_email text,
  plan text not null check (plan in ('starter','pro','business')),
  status text not null,
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Add Safepay columns safely for projects that already ran an earlier schema version.
alter table public.subscriptions add column if not exists provider text not null default 'safepay';
alter table public.subscriptions alter column provider set default 'safepay';
alter table public.subscriptions add column if not exists safepay_reference text;
alter table public.subscriptions add column if not exists safepay_subscription_id text;
alter table public.subscriptions add column if not exists safepay_plan_id text;
alter table public.subscriptions add column if not exists billing_email text;
create unique index if not exists subscriptions_safepay_reference_unique_idx on public.subscriptions(safepay_reference) where safepay_reference is not null;
create unique index if not exists subscriptions_safepay_subscription_unique_idx on public.subscriptions(safepay_subscription_id) where safepay_subscription_id is not null;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'subscriptions_provider_check') THEN
    ALTER TABLE public.subscriptions ADD CONSTRAINT subscriptions_provider_check CHECK (provider IN ('stripe','safepay'));
  END IF;
END $$;

create table if not exists public.usage_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tool text not null check (char_length(tool) <= 80),
  credits integer not null default 1 check (credits > 0 and credits <= 1000),
  created_at timestamptz not null default now()
);

create index if not exists subscriptions_user_id_idx on public.subscriptions(user_id);
create index if not exists subscriptions_safepay_reference_idx on public.subscriptions(safepay_reference);

-- Verified Safepay webhook event ledger (server-only; no browser access).
create table if not exists public.safepay_webhook_events (
  event_id text primary key,
  event_type text not null,
  payload jsonb not null,
  processed_at timestamptz not null default now()
);
alter table public.safepay_webhook_events enable row level security;
revoke all on public.safepay_webhook_events from anon, authenticated;
create index if not exists usage_events_user_created_idx on public.usage_events(user_id, created_at desc);

create table if not exists public.usage_monthly (
  user_id uuid not null references auth.users(id) on delete cascade,
  period_start date not null,
  credits_used integer not null default 0 check (credits_used >= 0),
  updated_at timestamptz not null default now(),
  primary key (user_id, period_start)
);
create index if not exists usage_monthly_period_idx on public.usage_monthly(period_start desc);

create table if not exists public.usage_reservations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  period_start date not null,
  credits integer not null check (credits > 0 and credits <= 10000),
  status text not null check (status in ('reserved','consumed','released')),
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists usage_reservations_expiry_idx on public.usage_reservations(status, expires_at);

create or replace function public.is_smartpix_admin()
returns boolean language sql stable security invoker set search_path = '' as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin', false);
$$;

create or replace function public.handle_new_smartpix_user()
returns trigger language plpgsql security definer set search_path = public, auth as $$
begin
  insert into public.profiles (id, display_name, email)
  values (new.id, left(new.raw_user_meta_data ->> 'display_name', 80), new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

create or replace function public.sync_smartpix_user_email()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set email = new.email where id = new.id;
  return new;
end;
$$;

drop trigger if exists on_smartpix_auth_user_email_updated on auth.users;
create trigger on_smartpix_auth_user_email_updated
after update of email on auth.users
for each row when (old.email is distinct from new.email)
execute procedure public.sync_smartpix_user_email();

drop trigger if exists on_smartpix_auth_user_created on auth.users;
create trigger on_smartpix_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_smartpix_user();

insert into public.profiles (id, display_name, email)
select id, left(raw_user_meta_data ->> 'display_name', 80), email
from auth.users
on conflict (id) do update set email = excluded.email;

alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.usage_events enable row level security;
alter table public.usage_monthly enable row level security;
alter table public.usage_reservations enable row level security;

revoke all on public.profiles from anon, authenticated;
revoke all on public.subscriptions from anon, authenticated;
revoke all on public.usage_events from anon, authenticated;
revoke all on public.usage_monthly from anon, authenticated;
revoke all on public.usage_reservations from anon, authenticated;
grant select on public.profiles to authenticated;
grant update(display_name) on public.profiles to authenticated;
grant select on public.subscriptions to authenticated;
grant select on public.usage_events to authenticated;
grant select on public.usage_monthly to authenticated;

drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin" on public.profiles for select to authenticated
using (id = (select auth.uid()) or (select public.is_smartpix_admin()));
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update to authenticated
using (id = (select auth.uid())) with check (id = (select auth.uid()));

drop policy if exists "subscriptions_select_own_or_admin" on public.subscriptions;
create policy "subscriptions_select_own_or_admin" on public.subscriptions for select to authenticated
using (user_id = (select auth.uid()) or (select public.is_smartpix_admin()));

drop policy if exists "usage_select_own_or_admin" on public.usage_events;
create policy "usage_select_own_or_admin" on public.usage_events for select to authenticated
using (user_id = (select auth.uid()) or (select public.is_smartpix_admin()));

-- Only trusted server-side service-role code should write subscriptions and usage events.
-- Never grant service-role credentials to browser code.


drop policy if exists "usage_monthly_select_own" on public.usage_monthly;
create policy "usage_monthly_select_own" on public.usage_monthly for select to authenticated
using (user_id = (select auth.uid()) or (select public.is_smartpix_admin()));

-- Atomic monthly credit reservation prevents parallel requests from exceeding a plan limit.
-- Unfinished reservations expire after 15 minutes and are refunded on the next reservation call.
create or replace function public.reconcile_smartpix_reservations()
returns integer language plpgsql security definer set search_path = public as $$
declare
  r record;
  v_count integer := 0;
begin
  for r in
    update public.usage_reservations
    set status = 'released', updated_at = now()
    where status = 'reserved' and expires_at < now()
    returning user_id, period_start, credits
  loop
    update public.usage_monthly
    set credits_used = greatest(0, credits_used - r.credits), updated_at = now()
    where user_id = r.user_id and period_start = r.period_start;
    v_count := v_count + 1;
  end loop;
  return v_count;
end;
$$;

create or replace function public.reserve_smartpix_credit(p_user_id uuid, p_limit integer, p_credits integer default 1)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_period date := date_trunc('month', now() at time zone 'utc')::date;
  v_used integer;
  v_id uuid := gen_random_uuid();
begin
  perform public.reconcile_smartpix_reservations();
  if p_user_id is null or p_limit < 1 or p_limit > 10000 or p_credits < 1 or p_credits > p_limit then
    return null;
  end if;
  insert into public.usage_monthly (user_id, period_start, credits_used)
  values (p_user_id, v_period, p_credits)
  on conflict (user_id, period_start) do update
    set credits_used = public.usage_monthly.credits_used + excluded.credits_used,
        updated_at = now()
    where public.usage_monthly.credits_used + excluded.credits_used <= p_limit
  returning credits_used into v_used;
  if not found then return null; end if;
  insert into public.usage_reservations (id, user_id, period_start, credits, status, expires_at)
  values (v_id, p_user_id, v_period, p_credits, 'reserved', now() + interval '15 minutes');
  return v_id;
end;
$$;

create or replace function public.complete_smartpix_credit(p_reservation_id uuid, p_tool text)
returns boolean language plpgsql security definer set search_path = public as $$
declare
  r record;
begin
  update public.usage_reservations
  set status = 'consumed', updated_at = now()
  where id = p_reservation_id and status = 'reserved'
  returning user_id, credits into r;
  if not found then return false; end if;
  insert into public.usage_events (user_id, tool, credits)
  values (r.user_id, left(coalesce(p_tool, 'ai-tool'), 80), r.credits);
  return true;
end;
$$;

create or replace function public.release_smartpix_credit(p_reservation_id uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare
  r record;
begin
  update public.usage_reservations
  set status = 'released', updated_at = now()
  where id = p_reservation_id and status = 'reserved'
  returning user_id, period_start, credits into r;
  if not found then return false; end if;
  update public.usage_monthly
  set credits_used = greatest(0, credits_used - r.credits), updated_at = now()
  where user_id = r.user_id and period_start = r.period_start;
  return true;
end;
$$;

revoke all on function public.reconcile_smartpix_reservations() from public, anon, authenticated;
revoke all on function public.reserve_smartpix_credit(uuid, integer, integer) from public, anon, authenticated;
revoke all on function public.complete_smartpix_credit(uuid, text) from public, anon, authenticated;
revoke all on function public.release_smartpix_credit(uuid) from public, anon, authenticated;
grant execute on function public.reconcile_smartpix_reservations() to service_role;
grant execute on function public.reserve_smartpix_credit(uuid, integer, integer) to service_role;
grant execute on function public.complete_smartpix_credit(uuid, text) to service_role;
grant execute on function public.release_smartpix_credit(uuid) to service_role;
