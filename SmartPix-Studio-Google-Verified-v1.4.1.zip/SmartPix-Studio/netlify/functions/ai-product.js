'use strict';
const crypto = require('node:crypto');
const { reply, allowRequest, decodeImageDataUrl, parseBody, reserveAIUsage, releaseAIUsage, recordAIUsage } = require('../lib/ai-utils');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return reply(405, { error: 'Method not allowed.' });
  if (process.env.AI_FEATURES_ENABLED !== 'true' || !process.env.OPENAI_API_KEY) {
    return reply(503, { error: 'AI Product Studio is not configured yet. The site owner must enable AI and add a valid provider key.' });
  }
  if (!allowRequest(event, 2)) return reply(429, { error: 'Too many AI edits. Please wait one minute and try again.' });

  let image; let prompt;
  try {
    const body = parseBody(event);
    image = decodeImageDataUrl(body.image);
    prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    if (prompt.length < 10 || prompt.length > 600) throw new Error('Describe the product edit in 10 to 600 characters.');
  } catch (error) { return reply(400, { error: error.message || 'Invalid image-edit request.' }); }

  let reservation;
  try { reservation = await reserveAIUsage(event, 'product-photo-ai', 5); }
  catch (_) { return reply(503, { error: 'Could not verify your account or reserve AI credits.' }); }
  if (reservation.error) return reservation.error;

  try {
    const form = new FormData();
    form.append('model', process.env.OPENAI_IMAGE_MODEL || 'gpt-image-2.5-flare');
    form.append('image[]', new Blob([image.buffer], { type: image.mime }), `smartpix-product.${image.extension}`);
    form.append('prompt', `Edit this product photograph. Preserve the product identity, shape, proportions, printed text, logo, colors and fine details. Do not invent or distort product labels. Apply this requested scene direction: ${prompt}`);
    form.append('size', '1024x1024');
    form.append('quality', 'medium');
    form.append('output_format', 'webp');
    form.append('output_compression', '80');
    form.append('safety_identifier', crypto.createHash('sha256').update(reservation.userId).digest('hex'));
    const response = await fetch('https://api.openai.com/v1/images/edits', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}` },
      body: form
    });
    if (!response.ok) {
      await releaseAIUsage(reservation);
      const status = response.status === 429 ? 429 : response.status === 401 || response.status === 403 ? 503 : 502;
      return reply(status, { error: status === 429 ? 'AI capacity is busy. Please try again later.' : 'The AI image provider could not complete this edit. Check API billing, model access and provider configuration.' });
    }
    const data = await response.json();
    const imageBase64 = data?.data?.[0]?.b64_json;
    if (typeof imageBase64 !== 'string' || imageBase64.length > 5_000_000) {
      await releaseAIUsage(reservation);
      return reply(502, { error: 'The AI provider returned an invalid or oversized image.' });
    }
    await recordAIUsage(reservation, 'product-photo-ai');
    return reply(200, { image: `data:image/webp;base64,${imageBase64}`, format: 'webp' });
  } catch (_) {
    await releaseAIUsage(reservation);
    return reply(502, { error: 'The AI image service could not complete this request. Your reserved credits have been released where possible.' });
  }
};
