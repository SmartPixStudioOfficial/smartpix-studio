"use strict";
const crypto = require('node:crypto');
const { reply } = require('../lib/ai-utils');

function validSignature(rawBody, received, secret) {
  if (!received || !secret || !/^[a-f0-9]{64}$/i.test(received)) return false;
  const expected = crypto.createHmac('sha256', secret).update(rawBody).digest();
  const actual = Buffer.from(received, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return reply(405, { error: 'Method not allowed.' });
  if (!process.env.SAFEPAY_WEBHOOK_SECRET || !process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return reply(503, { error: 'Safepay webhook processing is not configured.' });
  }
  try {
    const rawBody = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64').toString('utf8') : (event.body || '');
    const signature = event.headers?.['x-sfpy-signature'] || event.headers?.['X-SFPY-SIGNATURE'];
    if (!validSignature(rawBody, signature, process.env.SAFEPAY_WEBHOOK_SECRET)) return reply(401, { error: 'Invalid Safepay webhook signature.' });
    const payload = JSON.parse(rawBody);
    const eventId = String(payload.id || payload.token || '');
    const eventType = String(payload.type || '');
    const data = payload.data || {};
    if (!eventId || !eventType) return reply(400, { error: 'Webhook event is missing its ID or type.' });
    const supported = new Set(['subscription.created', 'subscription.payment.succeeded', 'subscription.payment.failed', 'subscription.cancelled', 'subscription.canceled', 'subscription.ended', 'subscription.paused', 'subscription.resumed']);
    if (!supported.has(eventType)) return reply(200, { received: true, ignored: true });
    let reference = String(data.reference || '');
    if (reference && !/^sp_[a-f0-9-]{36}$/i.test(reference)) return reply(400, { error: 'Webhook subscription reference is invalid.' });

    const base = process.env.SUPABASE_URL.replace(/\/$/, '');
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const headers = { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, 'Content-Type': 'application/json', Prefer: 'return=representation' };
    const duplicateCheck = await fetch(`${base}/rest/v1/safepay_webhook_events?event_id=eq.${encodeURIComponent(eventId)}&select=event_id`, { headers });
    if (!duplicateCheck.ok) return reply(503, { error: 'Could not check webhook idempotency.' });
    if ((await duplicateCheck.json()).length) return reply(200, { received: true, duplicate: true });

    // Current Safepay event payloads may omit the optional reference. In that case,
    // correlate using the unique pending checkout email + reusable plan ID.
    if (!reference) {
      const safepaySubId = String(data.subscription_id || data.sub_id || data.id || '');
      if (safepaySubId) {
        const subQuery = new URLSearchParams({ select: 'safepay_reference', provider: 'eq.safepay', safepay_subscription_id: `eq.${safepaySubId}`, limit: '1' });
        const subResponse = await fetch(`${base}/rest/v1/subscriptions?${subQuery}`, { headers });
        if (!subResponse.ok) return reply(503, { error: 'Could not look up the Safepay subscription ID.' });
        reference = (await subResponse.json())?.[0]?.safepay_reference || '';
      }
      if (!reference) {
        const email = String(data.customer_email || '').trim().toLowerCase();
        const planId = String(data.plan_id || '');
        if (!email || !planId) return reply(400, { error: 'Webhook is missing the reference and the fallback customer/plan identifiers.' });
        const eventSeconds = Number(payload.created_at?.seconds || data.created_at?.seconds || data.started_at?.seconds || 0);
        const pendingFilters = { select: 'safepay_reference', provider: 'eq.safepay', status: 'eq.pending', billing_email: `eq.${email}`, safepay_plan_id: `eq.${planId}`, order: 'created_at.desc', limit: '1' };
        if (Number.isFinite(eventSeconds) && eventSeconds > 0) {
          pendingFilters.created_at = `gte.${new Date((eventSeconds - 2 * 60 * 60) * 1000).toISOString()}`;
          pendingFilters.and = `(created_at.lte.${new Date((eventSeconds + 2 * 60 * 60) * 1000).toISOString()})`;
        } else {
          pendingFilters.created_at = `gte.${new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()}`;
        }
        const pendingQuery = new URLSearchParams(pendingFilters);
        const pendingResponse = await fetch(`${base}/rest/v1/subscriptions?${pendingQuery}`, { headers });
        if (!pendingResponse.ok) return reply(503, { error: 'Could not correlate Safepay webhook to a pending subscription.' });
        const pendingRows = await pendingResponse.json();
        reference = pendingRows?.[0]?.safepay_reference || '';
      }
      if (!reference) return reply(503, { error: 'No matching SmartPix subscription was found for this Safepay event.' });
    }

    const updates = {};
    if (eventType === 'subscription.created') {
      // Do not overwrite active access if webhook delivery order is delayed.
      updates.safepay_subscription_id = String(data.subscription_id || data.sub_id || data.id || '');
    } else if (eventType === 'subscription.payment.succeeded') {
      updates.status = 'active';
      updates.safepay_subscription_id = String(data.subscription_id || data.sub_id || data.id || '');
      if (Number.isFinite(Number(data.current_period_end_date?.seconds))) updates.current_period_end = new Date(Number(data.current_period_end_date.seconds) * 1000).toISOString();
    } else if (eventType === 'subscription.payment.failed') {
      updates.status = 'payment_failed';
    } else if (['subscription.cancelled', 'subscription.canceled', 'subscription.ended'].includes(eventType)) {
      updates.status = 'cancelled';
      updates.safepay_subscription_id = String(data.subscription_id || data.sub_id || data.id || '');
    } else if (eventType === 'subscription.paused') {
      updates.status = 'paused';
      updates.safepay_subscription_id = String(data.subscription_id || data.sub_id || data.id || '');
    } else if (eventType === 'subscription.resumed') {
      updates.status = 'active';
      updates.safepay_subscription_id = String(data.subscription_id || data.sub_id || data.id || '');
    }
    updates.updated_at = new Date().toISOString();
    Object.keys(updates).forEach((key) => { if (updates[key] === '') delete updates[key]; });
    const updateResponse = await fetch(`${base}/rest/v1/subscriptions?safepay_reference=eq.${encodeURIComponent(reference)}`, {
      method: 'PATCH', headers, body: JSON.stringify(updates)
    });
    if (!updateResponse.ok) return reply(503, { error: 'Could not update the matching subscription. Safepay may retry this event.' });
    const updatedRows = await updateResponse.json().catch(() => []);
    if (!Array.isArray(updatedRows) || updatedRows.length === 0) return reply(503, { error: 'No matching pending subscription was found for this Safepay reference.' });

    const storeResponse = await fetch(`${base}/rest/v1/safepay_webhook_events`, {
      method: 'POST', headers,
      body: JSON.stringify({ event_id: eventId, event_type: eventType, payload, processed_at: new Date().toISOString() })
    });
    if (!storeResponse.ok && storeResponse.status !== 409) return reply(503, { error: 'Could not store the processed webhook event.' });
    return reply(200, { received: true });
  } catch (error) {
    return reply(400, { error: error.message || 'Could not process Safepay webhook.' });
  }
};
