'use strict';
const { reply, allowRequest, decodeImageDataUrl, parseBody, reserveAIUsage, releaseAIUsage, recordAIUsage } = require('../lib/ai-utils');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return reply(405, { error: 'Method not allowed.' });
  if (process.env.AI_FEATURES_ENABLED !== 'true' || !process.env.LEONARDO_API_KEY) {
    return reply(503, { error: 'AI background removal is not configured yet. The site owner must enable AI and add a Leonardo API key.' });
  }
  if (!allowRequest(event, 3)) return reply(429, { error: 'Too many requests. Please wait one minute and try again.' });

  let image;
  try { image = decodeImageDataUrl(parseBody(event).image); }
  catch (error) { return reply(400, { error: error.message || 'Invalid image request.' }); }

  let reservation;
  try { reservation = await reserveAIUsage(event, 'background-removal', 1); }
  catch (_) { return reply(503, { error: 'Could not verify your account or reserve AI credits.' }); }
  if (reservation.error) return reservation.error;

  try {
    const response = await fetch('https://cloud.leonardo.ai/api/rest/v2/generationssync', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.LEONARDO_API_KEY}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        model: 'remove-bg',
        ephemeral: true,
        base64: true,
        parameters: {
          size: 'auto',
          format: 'webp',
          guidances: {
            image_reference: [{ image: { type: 'BASE64', data: image.buffer.toString('base64') } }]
          }
        }
      })
    });
    const data = await response.json().catch(() => ({}));
    const imageBase64 = data?.results?.[0]?.dataB64;
    if (!response.ok || data?.errors?.length || typeof imageBase64 !== 'string' || imageBase64.length > 5_000_000) {
      await releaseAIUsage(reservation);
      const message = data?.errors?.[0]?.message;
      return reply(response.status === 429 ? 429 : 502, { error: message || 'The background-removal provider could not process this image. Check API access, credits and configuration.' });
    }
    await recordAIUsage(reservation, 'background-removal');
    return reply(200, { image: `data:image/webp;base64,${imageBase64}`, format: 'webp' });
  } catch (_) {
    await releaseAIUsage(reservation);
    return reply(502, { error: 'The background-removal service could not complete this request. Your reserved credit has been released where possible.' });
  }
};
