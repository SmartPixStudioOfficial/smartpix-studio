"use strict";
const crypto = require('node:crypto');
const { reply, allowRequest, parseBody } = require('../lib/ai-utils');

const PLAN_ENV = {
  starter: 'SAFEPAY_PLAN_STARTER',
  pro: 'SAFEPAY_PLAN_PRO',
  business: 'SAFEPAY_PLAN_BUSINESS'
};

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return reply(405, { error: 'Method not allowed.' });
  const required = ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY', 'SITE_URL', 'SAFEPAY_SECRET_KEY', 'SAFEPAY_ENV'];
  if (required.some((key) => !process.env[key])) return reply(503, { error: 'Secure Safepay checkout is not configured yet. The site owner must complete merchant and server setup.' });
  if (!allowRequest(event, 5)) return reply(429, { error: 'Too many checkout attempts. Please wait and try again.' });

  try {
    const token = event.headers?.authorization?.replace(/^Bearer\s+/i, '');
    if (!token) return reply(401, { error: 'Sign in before choosing a paid plan.' });
    const base = process.env.SUPABASE_URL.replace(/\/$/, '');
    const authResponse = await fetch(`${base}/auth/v1/user`, {
      headers: { apikey: process.env.SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` }
    });
    if (!authResponse.ok) return reply(401, { error: 'Your session is not valid. Please sign in again.' });
    const user = await authResponse.json();
    const body = parseBody(event);
    const plan = String(body.plan || '').toLowerCase();
    if (!Object.hasOwn(PLAN_ENV, plan)) return reply(400, { error: 'Choose a valid SmartPix plan.' });
    const planId = process.env[PLAN_ENV[plan]];
    if (!planId) return reply(503, { error: 'This plan is not connected to Safepay yet.' });

    const serviceHeaders = {
      apikey: process.env.SUPABASE_SERVICE_ROLE_KEY,
      Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
      'Content-Type': 'application/json'
    };
    const pendingCutoff = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
    const activeQuery = new URLSearchParams({ select: 'id,status,created_at', user_id: `eq.${user.id}`, status: 'in.(active,pending)', limit: '10' });
    const activeResponse = await fetch(`${base}/rest/v1/subscriptions?${activeQuery}`, { headers: serviceHeaders });
    if (!activeResponse.ok) return reply(503, { error: 'Could not verify your current subscription. Please try again later.' });
    const existingSubscriptions = await activeResponse.json();
    const hasBlockingSubscription = existingSubscriptions.some((row) => row.status === 'active' || (row.status === 'pending' && Date.parse(row.created_at) >= Date.now() - 2 * 60 * 60 * 1000));
    if (hasBlockingSubscription) return reply(409, { error: 'You already have a paid or pending subscription. Contact support if you need to change plans.' });

    const siteUrl = new URL(process.env.SITE_URL);
    if (siteUrl.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(siteUrl.hostname)) return reply(500, { error: 'The checkout return URL must use HTTPS.' });
    const env = process.env.SAFEPAY_ENV;
    if (!['sandbox', 'production'].includes(env)) return reply(500, { error: 'SAFEPAY_ENV must be sandbox or production.' });
    const apiHost = env === 'production' ? 'https://api.getsafepay.com' : 'https://sandbox.api.getsafepay.com';
    const checkoutHost = env === 'production' ? 'https://getsafepay.com' : 'https://sandbox.api.getsafepay.com';
    const reference = `sp_${crypto.randomUUID()}`;

    // Persist the reference before redirecting; Safepay uses it to correlate webhooks.
    const insertResponse = await fetch(`${base}/rest/v1/subscriptions`, {
      method: 'POST',
      headers: { ...serviceHeaders, Prefer: 'return=representation' },
      body: JSON.stringify({ user_id: user.id, plan, status: 'pending', provider: 'safepay', safepay_reference: reference, safepay_plan_id: planId, billing_email: user.email ? String(user.email).trim().toLowerCase() : null })
    });
    if (!insertResponse.ok) return reply(503, { error: 'Could not create a pending subscription record. Apply the latest SmartPix database schema.' });

    const authTokenResponse = await fetch(`${apiHost}/client/passport/v1/token`, {
      method: 'POST',
      headers: { 'X-SFPY-MERCHANT-SECRET': process.env.SAFEPAY_SECRET_KEY, 'Content-Type': 'application/json' },
      body: '{}'
    });
    const authTokenData = await authTokenResponse.json().catch(() => ({}));
    const authToken = authTokenData.data;
    if (!authTokenResponse.ok || !authToken) {
      await fetch(`${base}/rest/v1/subscriptions?safepay_reference=eq.${encodeURIComponent(reference)}`, {
        method: 'PATCH', headers: serviceHeaders, body: JSON.stringify({ status: 'checkout_error' })
      });
      return reply(502, { error: 'Safepay could not create a secure checkout token. Check the merchant credentials and environment.' });
    }

    const successUrl = new URL('/billing-success.html', siteUrl);
    successUrl.searchParams.set('reference', reference);
    const cancelUrl = new URL('/#pricing', siteUrl);
    cancelUrl.searchParams.set('checkout', 'cancelled');
    const checkout = new URL('/checkout/auth/login', checkoutHost);
    checkout.searchParams.set('plan_id', planId);
    checkout.searchParams.set('auth_token', authToken);
    checkout.searchParams.set('env', env);
    checkout.searchParams.set('redirect_url', successUrl.toString());
    checkout.searchParams.set('cancel_url', cancelUrl.toString());
    checkout.searchParams.set('reference', reference);
    return reply(200, { url: checkout.toString() });
  } catch (error) {
    return reply(400, { error: error.message || 'Could not start secure checkout.' });
  }
};
