exports.handler = async () => {
  const aiEnabled = process.env.AI_FEATURES_ENABLED === 'true';
  const accountUsageReady = Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY && process.env.SUPABASE_SERVICE_ROLE_KEY);
  const limit = (key, fallback) => {
    const value = Number.parseInt(process.env[key] || '', 10);
    return Number.isInteger(value) && value > 0 ? Math.min(value, 10000) : fallback;
  };
  return {
    statusCode: 200,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
    body: JSON.stringify({
      ok: true,
      product: 'SmartPix Studio',
      capabilities: {
        freeBrowserTools: true,
        backgroundRemoval: aiEnabled && accountUsageReady && Boolean(process.env.LEONARDO_API_KEY),
        productPhotoAI: aiEnabled && accountUsageReady && Boolean(process.env.OPENAI_API_KEY),
        paymentsConfigured: Boolean(process.env.SAFEPAY_SECRET_KEY && process.env.SAFEPAY_WEBHOOK_SECRET && process.env.SAFEPAY_PLAN_STARTER && process.env.SAFEPAY_PLAN_PRO && process.env.SAFEPAY_PLAN_BUSINESS && process.env.SAFEPAY_ENV && process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY && process.env.SUPABASE_SERVICE_ROLE_KEY && process.env.SITE_URL),
        paymentProvider: 'Safepay'
      },
      aiCreditLimits: {
        starter: limit('AI_LIMIT_STARTER', 5),
        pro: limit('AI_LIMIT_PRO', 25),
        business: limit('AI_LIMIT_BUSINESS', 75)
      }
    })
  };
};
