const crypto = require('node:crypto');
const assert = require('node:assert/strict');
(async () => {
  process.env.SUPABASE_URL='https://demo.supabase.co'; process.env.SUPABASE_ANON_KEY='anon'; process.env.SUPABASE_SERVICE_ROLE_KEY='service';
  process.env.SITE_URL='https://smartpix.example'; process.env.SAFEPAY_ENV='sandbox'; process.env.SAFEPAY_SECRET_KEY='secret'; process.env.SAFEPAY_WEBHOOK_SECRET='hmac-secret';
  process.env.SAFEPAY_PLAN_STARTER='plan_starter'; process.env.SAFEPAY_PLAN_PRO='plan_pro'; process.env.SAFEPAY_PLAN_BUSINESS='plan_business';
  const checkout=require(process.cwd()+'/netlify/functions/safepay-checkout');
  const originalFetch=global.fetch; const calls=[];
  global.fetch=async(url,opts={})=>{calls.push({url:String(url),opts}); const u=String(url);
    if(u.includes('/auth/v1/user')) return new Response(JSON.stringify({id:'11111111-1111-4111-8111-111111111111',email:'Test@example.com'}),{status:200});
    if(u.includes('/rest/v1/subscriptions?')) return new Response('[]',{status:200});
    if(u.includes('/rest/v1/subscriptions')&&opts.method==='POST') {const row=JSON.parse(opts.body); assert.equal(row.billing_email,'test@example.com'); assert.equal(row.safepay_plan_id,'plan_pro'); return new Response('[{"id":"1"}]',{status:201});}
    if(u.includes('/client/passport/v1/token')) return new Response(JSON.stringify({data:'temporary-token'}),{status:200});
    throw new Error('Unexpected checkout fetch '+u);
  };
  const result=await checkout.handler({httpMethod:'POST',headers:{authorization:'Bearer jwt','x-nf-client-connection-ip':'10.1.1.1'},body:JSON.stringify({plan:'pro'})});
  assert.equal(result.statusCode,200); const checkoutUrl=new URL(JSON.parse(result.body).url);
  assert.equal(checkoutUrl.hostname,'sandbox.api.getsafepay.com'); assert.equal(checkoutUrl.searchParams.get('plan_id'),'plan_pro');
  assert.ok(checkoutUrl.searchParams.get('reference').startsWith('sp_')); assert.ok(calls.some(c=>c.url.includes('/rest/v1/subscriptions')&&c.opts.method==='POST'));
  console.log('PASS checkout: authenticated, pending row saved before redirect, sandbox checkout URL created');

  const webhook=require(process.cwd()+'/netlify/functions/safepay-webhook');
  let patched=[]; const seen=[];
  global.fetch=async(url,opts={})=>{const u=String(url);
    if(u.includes('/safepay_webhook_events?')) { const id=new URL(u).searchParams.get('event_id')?.replace(/^eq\./,''); return new Response(JSON.stringify(seen.some(e=>e.event_id===id)?[{event_id:id}]:[]),{status:200}); }
    if(u.includes('/rest/v1/subscriptions?')&&u.includes('billing_email')) return new Response('[{"safepay_reference":"sp_11111111-1111-4111-8111-111111111111"}]',{status:200});
    if(u.includes('/rest/v1/subscriptions?')&&u.includes('safepay_subscription_id')) return new Response('[{"safepay_reference":"sp_11111111-1111-4111-8111-111111111111"}]',{status:200});
    if(u.includes('/rest/v1/subscriptions?')&&opts.method==='PATCH') {const data=JSON.parse(opts.body); patched.push(data); return new Response('[{"id":"1"}]',{status:200});}
    if(u.endsWith('/rest/v1/safepay_webhook_events')) {seen.push(JSON.parse(opts.body)); return new Response(null,{status:201});}
    throw new Error('Unexpected webhook fetch '+u);
  };
  async function send(payload, ip){const raw=JSON.stringify(payload); const sig=crypto.createHmac('sha256','hmac-secret').update(raw).digest('hex'); return webhook.handler({httpMethod:'POST',headers:{'x-sfpy-signature':sig,'x-nf-client-connection-ip':ip},body:raw});}
  const created=await send({token:'evt_created',type:'subscription.created',data:{id:'sub_demo',plan_id:'plan_pro',customer_email:'test@example.com'}},'10.2.2.2');
  assert.equal(created.statusCode,200); assert.equal(patched[0].safepay_subscription_id,'sub_demo'); assert.equal(patched[0].status,undefined);
  const paid=await send({token:'evt_paid',type:'subscription.payment.succeeded',data:{id:'sub_demo',plan_id:'plan_pro',customer_email:'test@example.com',current_period_end_date:{seconds:1800000000}}},'10.2.2.3');
  assert.equal(paid.statusCode,200); assert.equal(patched[1].status,'active'); assert.ok(patched[1].current_period_end); assert.equal(seen.length,2);
  console.log('PASS webhook: accepts Safepay token/id payloads, correlates by customer+plan then subscription ID, activates only after successful payment');
  const duplicate=await send({token:'evt_paid',type:'subscription.payment.succeeded',data:{id:'sub_demo',plan_id:'plan_pro',customer_email:'test@example.com'}},'10.2.2.5');
  assert.equal(duplicate.statusCode,200); assert.equal(patched.length,2);
  console.log('PASS webhook idempotency: duplicate event does not reapply subscription changes');
  const bad=await webhook.handler({httpMethod:'POST',headers:{'x-sfpy-signature':'0'.repeat(64),'x-nf-client-connection-ip':'10.2.2.4'},body:'{}'});
  assert.equal(bad.statusCode,401); console.log('PASS webhook security: invalid HMAC rejected');
  global.fetch=originalFetch;
})().catch(e=>{console.error(e);process.exit(1)});
