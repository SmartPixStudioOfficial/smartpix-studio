'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const configured = process.env.SITE_URL || process.env.URL || '';
if (!configured) {
  console.log('SITE_URL/Netlify URL not supplied; keeping the documented placeholder until the final domain is known.');
  process.exit(0);
}
let site;
try { site = new URL(configured); } catch (_) { console.error('SITE_URL must be a valid HTTPS URL.'); process.exit(1); }
if (site.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(site.hostname)) {
  console.error('SITE_URL must use HTTPS.'); process.exit(1);
}
const origin = site.origin;
const placeholder = 'https://smartpixstudio.netlify.app';
const files = ['index.html', 'about.html', 'contact.html', 'privacy.html', 'terms.html', 'blog.html', 'sitemap.xml', 'robots.txt'];
for (const name of files) {
  const file = path.join(root, name);
  if (!fs.existsSync(file)) continue;
  const before = fs.readFileSync(file, 'utf8');
  const after = before.replaceAll(placeholder, origin);
  if (after !== before) fs.writeFileSync(file, after);
}
console.log(`Canonical URLs, sitemap and robots.txt set to ${origin}`);
