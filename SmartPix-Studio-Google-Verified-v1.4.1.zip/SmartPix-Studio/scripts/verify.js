'use strict';
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const errors = [];
const required = [
  'index.html', 'styles.css', 'scripts/set-site-url.js', 'scripts/test-safepay.js', 'app.js', 'config.js', 'billing.js', 'auth.js', 'dashboard.js', 'admin.js', 'robots.txt', 'sitemap.xml',
  'about.html', 'contact.html', 'contact-success.html', 'privacy.html', 'terms.html', 'blog.html', '404.html', 'auth.html', 'dashboard.html', 'admin.html', 'billing-success.html', 'supabase/schema.sql',
  '_headers', 'netlify.toml', 'netlify/functions/health.js',
  'netlify/lib/ai-utils.js', 'netlify/functions/ai-background.js', 'netlify/functions/ai-product.js',
  'netlify/functions/safepay-checkout.js', 'netlify/functions/safepay-webhook.js'
];
for (const file of required) if (!fs.existsSync(path.join(root, file))) errors.push(`Missing required file: ${file}`);
const htmlFiles = fs.readdirSync(root).filter((name) => name.endsWith('.html'));
for (const file of htmlFiles) {
  const html = fs.readFileSync(path.join(root, file), 'utf8');
  if (!/<title>[^<]+<\/title>/i.test(html)) errors.push(`${file}: missing page title`);
  if (!/<meta\s+name=["']description["'][^>]*content=["'][^"']+/i.test(html)) errors.push(`${file}: missing meta description`);
  const refs = [...html.matchAll(/(?:src|href)=["'](\/(?!\/)[^"'#?]+)["']/g)].map((m) => m[1]);
  const idList = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map((m) => m[1]);
  const ids = new Set(idList);
  if (ids.size !== idList.length) errors.push(`${file}: duplicate element IDs`);
  for (const match of html.matchAll(/href=["']#([^"']+)["']/g)) if (!ids.has(match[1])) errors.push(`${file}: missing in-page anchor #${match[1]}`);
  for (const ref of refs) {
    const target = path.join(root, decodeURIComponent(ref).replace(/^\//, ''));
    if (!fs.existsSync(target) && !ref.endsWith('/')) errors.push(`${file}: broken local reference ${ref}`);
  }
}
const home = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const requiredIds = ['imageInput','previewStage','processBtn','downloadBtn','toolSelect','formatSelect','widthInput','heightInput','keepRatio','qualityInput','watermarkText','rotateSelect','cropX','cropY','cropWidth','cropHeight','flipHorizontal','flipVertical','brightnessInput','contrastInput','saturationInput','aiMode','aiImageInput','aiProcessBtn','aiPreviewStage','aiDownloadBtn','aiPrompt'];
for (const id of requiredIds) if (!new RegExp('id=[\"\\\']' + id + '[\"\\\']').test(home)) errors.push(`index.html: missing control ${id}`);
for (const tool of ['resize','compress','convert','watermark','crop','rotate','adjust']) if (!home.includes(`value=\"${tool}\"`) || !app.includes(`tool === '${tool}'`) && !app.includes(`tool === \"${tool}\"`)) errors.push(`Tool configuration missing or incomplete: ${tool}`);
if (!fs.existsSync(path.join(root, '_headers'))) errors.push('Missing deployment security headers file');
const authHtml = fs.readFileSync(path.join(root, 'auth.html'), 'utf8');
for (const id of ['signInForm','signUpForm','resetPasswordForm','authStatus']) if (!authHtml.includes(`id=\"${id}\"`)) errors.push(`auth.html: missing ${id}`);
const schema = fs.readFileSync(path.join(root, 'supabase/schema.sql'), 'utf8');
for (const marker of ['enable row level security','reserve_smartpix_credit','release_smartpix_credit','complete_smartpix_credit','usage_reservations','service_role']) if (!schema.includes(marker)) errors.push(`supabase/schema.sql: missing ${marker}`);
const config = fs.readFileSync(path.join(root, 'config.js'), 'utf8');
if (/sk_(?:live|test)_[A-Za-z0-9]+|service_role_key\s*:/i.test(config)) errors.push('config.js: secret-looking credential must not be shipped to browsers');
const { execFileSync } = require('child_process');
for (const file of ['scripts/set-site-url.js','scripts/test-safepay.js','app.js','netlify/functions/health.js','netlify/lib/ai-utils.js','netlify/functions/ai-background.js','netlify/functions/ai-product.js','netlify/functions/safepay-checkout.js','netlify/functions/safepay-webhook.js']) {
  try { execFileSync(process.execPath, ['--check', path.join(root, file)], { stdio: 'pipe' }); }
  catch (_) { errors.push(`${file}: JavaScript syntax check failed`); }
}
const sitemap = fs.readFileSync(path.join(root, 'sitemap.xml'), 'utf8');
if (!sitemap.includes('<urlset')) errors.push('sitemap.xml: missing urlset');
const robots = fs.readFileSync(path.join(root, 'robots.txt'), 'utf8');
if (!/Sitemap:\s*https?:\/\//i.test(robots)) errors.push('robots.txt: missing absolute sitemap URL');
for (const file of ['auth.js','dashboard.js','admin.js','billing.js']) {
  try { execFileSync(process.execPath, ['--input-type=module', '--check'], { input: fs.readFileSync(path.join(root, file), 'utf8'), stdio: ['pipe', 'pipe', 'pipe'] }); }
  catch (_) { errors.push(`${file}: ES module syntax check failed`); }
}
const healthSource = fs.readFileSync(path.join(root, 'netlify/functions/health.js'), 'utf8');
if (!healthSource.includes('SAFEPAY_SECRET_KEY') || !healthSource.includes("paymentProvider: 'Safepay'")) errors.push('Health endpoint does not report Safepay configuration');
const safepayCheckout = fs.readFileSync(path.join(root, 'netlify/functions/safepay-checkout.js'), 'utf8');
const safepayWebhook = fs.readFileSync(path.join(root, 'netlify/functions/safepay-webhook.js'), 'utf8');
for (const marker of ['SAFEPAY_PLAN_STARTER','SAFEPAY_PLAN_PRO','SAFEPAY_PLAN_BUSINESS','/client/passport/v1/token','safepay_reference']) if (!safepayCheckout.includes(marker)) errors.push(`Safepay checkout missing ${marker}`);
for (const marker of ['x-sfpy-signature','timingSafeEqual','subscription.payment.succeeded','subscription.cancelled']) if (!safepayWebhook.includes(marker)) errors.push(`Safepay webhook missing ${marker}`);
const updatedSchema = fs.readFileSync(path.join(root, 'supabase/schema.sql'), 'utf8');
for (const marker of ['safepay_reference','safepay_subscription_id','safepay_plan_id','billing_email','safepay_webhook_events']) if (!updatedSchema.includes(marker)) errors.push(`Supabase schema missing ${marker}`);
if (errors.length) {
  console.error('SmartPix QA FAILED'); errors.forEach((e) => console.error(`- ${e}`)); process.exit(1);
}
console.log(`SmartPix QA passed: ${required.length} required files, ${htmlFiles.length} HTML pages, seven free tools, AI/payment controls and server function syntax checked.`);
console.log('Reminder: external credentials, legal review, provider integrations and live deployment are not verified by this local check.');
