import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const config = window.SMARTPIX_CONFIG || {};
const status = document.getElementById('adminStatus');
if (!config.supabaseUrl || !config.supabaseAnonKey) {
  status.textContent = 'Supabase is not configured. This restricted page is unavailable.';
} else {
  const supabase = createClient(config.supabaseUrl, config.supabaseAnonKey);
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) window.location.replace('/auth.html');
  else {
    const { data: { user } } = await supabase.auth.getUser();
    if (user?.app_metadata?.role !== 'admin') status.textContent = 'Access denied. An administrator role is required.';
    else {
      status.textContent = 'Administrator access verified.';
      const [{ data: profiles, error: profilesError }, { data: subscriptions, error: subsError }, { count: profileCount, error: countError }] = await Promise.all([
        supabase.from('profiles').select('id,email,display_name,created_at').order('created_at', { ascending: false }).limit(100),
        supabase.from('subscriptions').select('user_id,plan,status'),
        supabase.from('profiles').select('id', { count: 'exact', head: true })
      ]);
      if (profilesError || subsError || countError) status.textContent = 'Admin access is verified, but database tables or policies need setup.';
      else {
        document.getElementById('adminUsers').textContent = String(profileCount ?? profiles.length);
        document.getElementById('adminSubscriptions').textContent = String(subscriptions.filter((row) => ['active','trialing'].includes(row.status)).length);
        const tbody = document.getElementById('adminRows'); tbody.replaceChildren();
        for (const profile of profiles) {
          const sub = subscriptions.find((row) => row.user_id === profile.id);
          const tr = document.createElement('tr');
          for (const value of [profile.email || profile.display_name || profile.id, sub?.plan || 'Free', sub?.status || '—', new Date(profile.created_at).toLocaleDateString()]) {
            const td = document.createElement('td'); td.textContent = value; tr.appendChild(td);
          }
          tbody.appendChild(tr);
        }
      }
    }
  }
}
