import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const config = window.SMARTPIX_CONFIG || {};
const status = document.getElementById('authStatus');
const signInForm = document.getElementById('signInForm');
const signUpForm = document.getElementById('signUpForm');
const supabase = config.supabaseUrl && config.supabaseAnonKey ? createClient(config.supabaseUrl, config.supabaseAnonKey) : null;
const showMessage = (message, error = false) => { status.textContent = message; status.classList.toggle('error', error); };
if (!supabase) showMessage('Account services are not connected yet. The site owner must add the Supabase project URL and publishable/anon key to config.js.');

document.querySelectorAll('[data-auth-tab]').forEach((tab) => tab.addEventListener('click', () => {
  const signup = tab.dataset.authTab === 'signup';
  signInForm.classList.toggle('hidden', signup); signUpForm.classList.toggle('hidden', !signup);
  document.querySelectorAll('[data-auth-tab]').forEach((item) => item.classList.toggle('active', item === tab));
  showMessage(signup ? 'Create your account using a valid email address.' : 'Sign in to continue.');
}));

signInForm.addEventListener('submit', async (event) => {
  event.preventDefault(); if (!supabase) return;
  const button = signInForm.querySelector('button[type=submit]'); button.disabled = true;
  try {
    const { error } = await supabase.auth.signInWithPassword({ email: document.getElementById('signInEmail').value.trim(), password: document.getElementById('signInPassword').value });
    if (error) throw error; window.location.assign('/dashboard.html');
  } catch (error) { showMessage(error.message || 'Could not sign in.', true); }
  finally { button.disabled = false; }
});

signUpForm.addEventListener('submit', async (event) => {
  event.preventDefault(); if (!supabase) return;
  const button = signUpForm.querySelector('button[type=submit]'); button.disabled = true;
  try {
    const { data, error } = await supabase.auth.signUp({
      email: document.getElementById('signUpEmail').value.trim(),
      password: document.getElementById('signUpPassword').value,
      options: { data: { display_name: document.getElementById('signUpName').value.trim() }, emailRedirectTo: `${config.siteUrl}/dashboard.html` }
    });
    if (error) throw error;
    if (data.session) window.location.assign('/dashboard.html');
    else showMessage('Account created. Check your email to confirm your address, then sign in.');
  } catch (error) { showMessage(error.message || 'Could not create your account.', true); }
  finally { button.disabled = false; }
});

document.getElementById('forgotPassword').addEventListener('click', async () => {
  if (!supabase) return;
  const email = document.getElementById('signInEmail').value.trim();
  if (!email) { showMessage('Enter your email address first.', true); return; }
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${config.siteUrl}/auth.html` });
    if (error) throw error; showMessage('If this email is registered, a password-reset link will be sent.');
  } catch (error) { showMessage(error.message || 'Could not send a reset email.', true); }
});

const resetForm = document.getElementById('resetPasswordForm');
if (supabase) {
  supabase.auth.onAuthStateChange((event) => {
    if (event === 'PASSWORD_RECOVERY') {
      signInForm.classList.add('hidden'); signUpForm.classList.add('hidden');
      document.querySelector('.auth-tabs').classList.add('hidden');
      resetForm.classList.remove('hidden');
      showMessage('Choose a new password for your account.');
    }
  });
}
resetForm.addEventListener('submit', async (event) => {
  event.preventDefault(); if (!supabase) return;
  const button = resetForm.querySelector('button[type=submit]'); button.disabled = true;
  try {
    const { error } = await supabase.auth.updateUser({ password: document.getElementById('newPassword').value });
    if (error) throw error;
    resetForm.classList.add('hidden'); showMessage('Your password has been updated. You can now sign in.');
    signInForm.classList.remove('hidden'); document.querySelector('.auth-tabs').classList.remove('hidden');
  } catch (error) { showMessage(error.message || 'Could not update the password.', true); }
  finally { button.disabled = false; }
});
