SMARTPIX STUDIO — A-TO-Z WEBSITE PACKAGE
========================================
Version: 1.4.0

WHAT IS INCLUDED
----------------
- Premium responsive landing page and image workspace.
- Seven functional, browser-based tools: resize, crop, compress, convert (PNG/JPG/WebP), text watermark, rotate/flip, and photo adjustments (brightness, contrast, saturation).
- Local image processing: supported free-tool images are handled in the visitor's browser; the original file is not overwritten.
- Input validation: JPG/PNG/WebP only, 20 MB upload limit, output pixel safety limit, and clear error feedback.
- Preview, output size comparison and download.
- Free, Starter, Pro and Business pricing presentation (prices are proposed, not active subscriptions).
- SEO metadata, canonical URLs, Open Graph/Twitter metadata and WebApplication structured data.
- robots.txt, sitemap.xml, favicon, social preview artwork and PWA manifest.
- About, Contact (Netlify Forms), Contact Success, Privacy, Terms, Blog, 404, account sign-in/sign-up, user dashboard, restricted admin overview and billing-return pages.
- Netlify deployment config, security headers, health function, server-side Leonardo.Ai/OpenAI image adapters, Supabase Auth/database foundation, Safepay recurring subscription checkout and HMAC-verified webhook handling.
- Local QA script: `npm run check` (or `node scripts/verify.js`). Safepay mocked integration/security tests: `npm run test:safepay`.

IMPORTANT: WHAT IS NOT LIVE YET
-------------------------------
This package is a functional website foundation, not a fully launched SaaS business. These items are intentionally not represented as active:
1. AI background removal and AI product-photo editing are wired to the Leonardo.Ai Sync API and OpenAI Images API through server-side functions. They require a signed-in user with an active paid subscription. Monthly credits are atomically reserved in Supabase before processing: background removal costs 1 credit and product-photo editing costs 5. Default monthly plan limits are Starter 5, Pro 25 and Business 75 credits; override with AI_LIMIT_STARTER, AI_LIMIT_PRO and AI_LIMIT_BUSINESS. Recheck current Leonardo and OpenAI API costs before locking the displayed subscription prices or credit allowances. AI remains disabled until provider and Supabase keys are configured, AI_FEATURES_ENABLED=true, provider billing/permissions are confirmed, and real requests are tested. The in-memory per-IP throttle is best-effort only; add a durable distributed rate limiter/WAF before public launch. Unfinished AI reservations expire after 15 minutes and are reconciled/refunded when the next AI request is reserved. If the site has no further AI requests, the dashboard may show a stale reservation until reconciliation runs.
2. Account screens, Supabase Auth wiring (sign-up, sign-in, email confirmation and password reset), row-level-secured database schema, monthly AI credit metering and a restricted admin overview are included, but remain inactive until a Supabase project is configured. Cloud image storage is not included.
3. Safepay subscription checkout and HMAC-verified webhook code are included. They cannot be activated until a Safepay merchant account is approved, sandbox/live plan IDs are created, Supabase is configured, and webhook endpoints are registered. Redirects never activate paid access; only verified subscription webhooks do.
4. Contact messages require Netlify Forms to be enabled on the deployed site and email notifications to be configured.
5. Privacy Policy and Terms are starter drafts. Owner and qualified legal review are required for the business's country, target markets and actual providers.
6. Live hosting, custom domain, DNS, Search Console ownership, analytics and production monitoring require owner account access.

AI image requests can take longer than static-page requests; verify function duration on the selected Netlify plan and move slow jobs to a background worker if needed. The site uses CSP and common browser security headers; review the policy if adding analytics or third-party scripts. Never paste API secrets into HTML or app.js. Store them only as protected Netlify environment variables. AI variables: AI_FEATURES_ENABLED=true, LEONARDO_API_KEY, OPENAI_API_KEY. Optional: OPENAI_IMAGE_MODEL (defaults to gpt-image-2.5-flare). Leonardo background removal uses ephemeral processing so source/result assets are not saved in the provider library by default. Supabase variables: SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY. Safepay variables: SAFEPAY_ENV=sandbox, SAFEPAY_SECRET_KEY, SAFEPAY_WEBHOOK_SECRET, SAFEPAY_PLAN_STARTER, SAFEPAY_PLAN_PRO, SAFEPAY_PLAN_BUSINESS, SITE_URL. Sandbox and production use different secret and HMAC keys. Create recurring plans in Safepay Dashboard (Subscriptions > Plans) and use the matching plan IDs for the selected environment. Keep AI_FEATURES_ENABLED unset/false until provider keys, billing and durable usage controls are ready. Never put SUPABASE_SERVICE_ROLE_KEY or Safepay secrets in config.js.

DEPLOY TO NETLIFY
-----------------
The site uses Netlify Functions for AI, Safepay subscription checkout and verified subscription webhooks. A drag-and-drop static deploy does NOT publish these functions.

Recommended Git deployment:
1. Extract the ZIP and create a Git repository from the contents of the `SmartPix-Studio` folder (the folder containing index.html).
2. Push the repository to a Git provider such as GitHub.
3. In Netlify, choose Add new site > Import an existing project and connect that repository.
4. Confirm the build command is `npm run build`, publish directory is `.`, and functions directory is `netlify/functions` (all are set in netlify.toml).
5. Deploy. Confirm the home page, /404.html, /robots.txt, /sitemap.xml and /api/health.
6. Set `SITE_URL` in Netlify to the final HTTPS Netlify URL or custom domain. The build script automatically updates canonical tags, sitemap.xml and robots.txt from `SITE_URL` (or Netlify’s primary `URL`). Do not submit the placeholder domain to search engines.
7. In Netlify Forms, confirm the `smartpix-contact` form is detected and configure monitored email notifications.
8. Add the final domain to Google Search Console and submit `/sitemap.xml` after deployment.

Alternative CLI deployment: install Node.js, run `npm install`, authenticate with `npx netlify login`, link the Netlify site with `npx netlify link`, then run `npx netlify deploy --prod` from this project folder. The included netlify.toml configures the functions directory.

A manual drag-and-drop deploy can publish only the static free-tool pages; it will not activate server functions, AI, account-aware billing or webhooks.

ACCOUNT AND BILLING SETUP
------------------------
1. Create a Supabase project and run `supabase/schema.sql` in its SQL Editor.
2. Put the project URL and publishable/anon key in `config.js`. These are public client values; never put the service-role key there.
3. Configure email confirmation, password reset redirect URLs and allowed site URLs in Supabase Auth.
4. To grant the owner admin access, use the Supabase SQL Editor with the owner account UUID: `update auth.users set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb where id = 'OWNER-USER-UUID';` Then sign out and back in to refresh the JWT. Never let a normal user set their own app_metadata role.
5. In the Safepay Dashboard, create recurring monthly plans for Starter, Pro and Business (PKR or USD as approved), then add their plan IDs and the matching sandbox credentials to Netlify environment variables. Create a separate set of live plans and credentials after live approval.
6. Set the monthly AI limits if needed: AI_LIMIT_STARTER=5, AI_LIMIT_PRO=25, AI_LIMIT_BUSINESS=75. Background removal consumes 1 credit; AI product editing consumes 5 credits.
7. Register `https://YOUR-DOMAIN/api/safepay-webhook` in Safepay Dashboard > Developers > Endpoints. Subscribe to `subscription.created`, `subscription.payment.succeeded`, `subscription.payment.failed` and `subscription.canceled` / `subscription.cancelled`, `subscription.ended`, `subscription.paused` and `subscription.resumed` (v2.0.0). Store the environment-specific HMAC key as SAFEPAY_WEBHOOK_SECRET. Subscription access is updated only by verified webhook events, not the browser return page. The webhook handler correlates using Safepay reference when supplied, with a bounded pending-checkout email + plan-ID fallback for payload versions that omit it.
8. Configure `SITE_URL` to the final HTTPS domain and test in Safepay sandbox before any live payment.

QUALITY CHECK
-------------
Run `npm run check` and `npm run test:safepay` in this folder. These check required files, page titles/descriptions, local asset references, sitemap/robots presence, free-tool controls, server-function syntax, mocked Safepay checkout, webhook signature rejection, subscription activation and duplicate-event handling. They do not replace live sandbox, browser, mobile, accessibility, security, legal or deployment testing. It is a static QA check; it does not replace browser, mobile, accessibility, security, legal or live-deployment testing.

PRODUCTION COMPLETION CHECKLIST
-------------------------------
[ ] Confirm SITE_URL is the final HTTPS domain and the generated canonical tags, sitemap.xml and robots.txt use it.
[ ] Deploy and test on the final HTTPS domain.
[ ] Configure Netlify Forms notifications and test a real contact submission.
[ ] Add LEONARDO_API_KEY and OPENAI_API_KEY as protected environment variables, then set AI_FEATURES_ENABLED=true only after provider billing and test calls are verified. Update privacy disclosures for the chosen providers.
[ ] Add a durable distributed rate limiter/WAF and monitor AI provider costs and quota consumption.
[ ] Configure Safepay plans, checkout, verified webhooks, cancellation/refund workflow and sandbox end-to-end tests before live mode.
[ ] Complete accessibility, cross-browser, mobile, performance, security and legal reviews.
[ ] Set up monitoring, backups, incident contact and support operations.

The free browser tools can be used without AI or payment credentials once the site is deployed. Paid and AI features must remain clearly marked as unavailable until their integrations are complete and verified.


SAFEPAY SUBSCRIPTION NOTES
--------------------------
- Checkout uses Safepay hosted subscription checkout; the customer explicitly authorizes recurring billing.
- A plan is activated only after a valid `subscription.payment.succeeded` webhook.
- Subscription cancellation/refunds are currently managed from the Safepay Merchant Dashboard; the in-site self-service cancellation portal is not included in this release.
- Do not enable production until a sandbox payment and each webhook event have been verified.
