import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const config = window.SMARTPIX_CONFIG || {};
const message = document.getElementById('dashboardMessage');
const supabase = config.supabaseUrl && config.supabaseAnonKey ? createClient(config.supabaseUrl, config.supabaseAnonKey) : null;
const signOut = document.getElementById('signOutButton');
if (!supabase) {
  document.getElementById('dashboardGreeting').textContent = 'Account services are not configured. Connect Supabase in config.js and apply supabase/schema.sql.';
  signOut.disabled = true;
} else {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) window.location.replace('/auth.html');
  else {
    document.getElementById('dashboardGreeting').textContent = `Welcome back, ${session.user.user_metadata?.display_name || session.user.email}.`;
    document.getElementById('profileEmail').textContent = session.user.email || '';
    document.getElementById('profileCreated').textContent = `Member since ${new Date(session.user.created_at).toLocaleDateString()}`;
    const [{ data: profile, error: profileError }, { data: subscription, error: subscriptionError }, { data: usage, error: usageError }, { data: claims }] = await Promise.all([
      supabase.from('profiles').select('display_name,created_at').eq('id', session.user.id).maybeSingle(),
      supabase.from('subscriptions').select('plan,status,current_period_end,provider,safepay_subscription_id').eq('user_id', session.user.id).order('created_at', { ascending: false }).limit(1).maybeSingle(),
      supabase.from('usage_monthly').select('credits_used').eq('user_id', session.user.id).eq('period_start', new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1)).toISOString().slice(0, 10)).maybeSingle(),
      supabase.auth.getUser()
    ]);
    document.getElementById('planName').textContent = subscription?.plan || 'Free';
    document.getElementById('planStatus').textContent = subscription ? `${subscription.status}${subscription.current_period_end ? ` · renews/ends ${new Date(subscription.current_period_end).toLocaleDateString()}` : ''}` : 'Free plan · no paid subscription';
    if (subscription?.provider === 'safepay') document.getElementById('billingHelp').classList.remove('hidden');
    let limits = { starter: 5, pro: 25, business: 75 };
    try { const health = await fetch('/api/health', { cache: 'no-store' }).then((response) => response.json()); limits = health.aiCreditLimits || limits; } catch (_) {}
    const monthlyUsed = Number(usage?.credits_used || 0);
    const monthlyLimit = limits[subscription?.plan] || 0;
    document.getElementById('usageCount').textContent = monthlyLimit ? `${monthlyUsed} / ${monthlyLimit}` : `${monthlyUsed} · Free plan`;
    if (claims?.data?.user?.app_metadata?.role === 'admin') document.getElementById('adminLink').classList.remove('hidden');
    if (profile?.display_name) document.getElementById('dashboardGreeting').textContent = `Welcome back, ${profile.display_name}.`;
    if (profileError || subscriptionError || usageError || (!profile && !subscription && !usage)) message.textContent = 'Your account is connected, but the database schema or access policies need setup. Apply supabase/schema.sql and retry.';
  }
}
signOut.addEventListener('click', async () => { if (!supabase) return; await supabase.auth.signOut(); window.location.assign('/auth.html'); });
