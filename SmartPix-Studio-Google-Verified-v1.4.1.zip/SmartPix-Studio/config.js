/* Public client configuration only. Never put secret/service-role keys here. */
window.SMARTPIX_CONFIG = {
  supabaseUrl: '',
  supabaseAnonKey: '',
  siteUrl: window.location.origin
};
