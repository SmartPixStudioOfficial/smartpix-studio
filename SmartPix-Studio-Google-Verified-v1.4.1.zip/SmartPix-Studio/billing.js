import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const config = window.SMARTPIX_CONFIG || {};
const supabase = config.supabaseUrl && config.supabaseAnonKey ? createClient(config.supabaseUrl, config.supabaseAnonKey) : null;
window.smartpixGetAccessToken = async () => {
  if (!supabase) return null;
  const { data: { session } } = await supabase.auth.getSession();
  return session?.access_token || null;
};
if (supabase) {
  const updateAccountLink = async () => {
    const link = document.querySelector('.nav-login');
    if (!link) return;
    const { data: { session } } = await supabase.auth.getSession();
    link.textContent = session ? 'Dashboard' : 'Sign in';
    link.href = session ? '/dashboard.html' : '/auth.html';
  };
  supabase.auth.onAuthStateChange(() => { updateAccountLink(); });
  updateAccountLink();
}
function toast(message) {
  const node = document.getElementById('toast');
  if (!node) return;
  node.textContent = message; node.classList.add('show');
  window.clearTimeout(toast.timer); toast.timer = window.setTimeout(() => node.classList.remove('show'), 3200);
}
document.querySelectorAll('.paid-plan').forEach((button) => button.addEventListener('click', async () => {
  if (!supabase) { toast('Account and checkout services are not configured yet.'); return; }
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) { window.location.assign('/auth.html'); return; }
  button.disabled = true; const original = button.textContent; button.textContent = 'Opening secure checkout…';
  try {
    const response = await fetch('/api/safepay-checkout', {
      method: 'POST',
      headers: { 'content-type': 'application/json', Authorization: `Bearer ${session.access_token}`, accept: 'application/json' },
      body: JSON.stringify({ plan: button.dataset.plan })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.url) throw new Error(data.error || 'Checkout is not available yet.');
    window.location.assign(data.url);
  } catch (error) { toast(error.message || 'Could not open checkout.'); }
  finally { button.disabled = false; button.textContent = original; }
}));
