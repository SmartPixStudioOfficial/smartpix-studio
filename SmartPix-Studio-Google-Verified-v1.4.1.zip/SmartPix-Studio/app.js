(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const input = $('imageInput');
  const stage = $('previewStage');
  const processButton = $('processBtn');
  const download = $('downloadBtn');
  let sourceImage = null;
  let sourceName = 'image';
  let sourceUrl = null;
  let resultUrl = null;
  let sourceFile = null;
  let processingVersion = 0;

  const toast = (message) => {
    const node = $('toast');
    if (!node) return;
    node.textContent = message;
    node.classList.add('show');
    window.clearTimeout(toast.timer);
    toast.timer = window.setTimeout(() => node.classList.remove('show'), 2800);
  };
  const revoke = (url) => { if (url) URL.revokeObjectURL(url); };
  const formatBytes = (bytes) => bytes < 1024 * 1024
    ? `${(bytes / 1024).toFixed(1)} KB`
    : `${(bytes / (1024 * 1024)).toFixed(2)} MB`;

  $('year').textContent = new Date().getFullYear();
  $('menuToggle')?.addEventListener('click', () => {
    const nav = document.querySelector('.desktop-nav');
    const open = nav?.classList.toggle('open') ?? false;
    $('menuToggle').setAttribute('aria-expanded', String(open));
  });

  document.querySelectorAll('[data-tool]').forEach((button) => button.addEventListener('click', () => {
    $('toolSelect').value = button.dataset.tool;
    $('workspace').scrollIntoView({ behavior: 'smooth', block: 'start' });
    syncTool();
    invalidateResult();
  }));
  document.querySelectorAll('a[href^="#"]').forEach((link) => link.addEventListener('click', () => {
    document.querySelector('.desktop-nav')?.classList.remove('open');
    $('menuToggle')?.setAttribute('aria-expanded', 'false');
  }));

  $('toolSelect').addEventListener('change', () => { syncTool(); invalidateResult(); });
  $('qualityInput').addEventListener('input', () => {
    $('qualityValue').textContent = `${$('qualityInput').value}%`;
    invalidateResult();
  });
  $('keepRatio').addEventListener('change', () => { updateHeightFromWidth(); invalidateResult(); });
  $('widthInput').addEventListener('input', () => {
    if ($('keepRatio').checked) updateHeightFromWidth();
    invalidateResult();
  });
  $('heightInput').addEventListener('input', invalidateResult);

  function invalidateResult() {
    processingVersion += 1;
    if (!resultUrl) return;
    revoke(resultUrl); resultUrl = null;
    download.classList.add('disabled'); download.removeAttribute('href');
    if (sourceUrl) {
      stage.replaceChildren();
      const preview = new Image(); preview.alt = 'Original image preview'; preview.src = sourceUrl;
      stage.appendChild(preview);
      $('previewStatus').textContent = 'Original image';
      $('resultMeta').textContent = 'Settings changed — process the image again';
    }
  }

  function updateHeightFromWidth() {
    if (!sourceImage || !$('keepRatio').checked) return;
    const width = Number($('widthInput').value);
    if (width > 0) $('heightInput').value = Math.max(1, Math.round(sourceImage.height * width / sourceImage.width));
  }

  function syncTool() {
    const tool = $('toolSelect').value;
    const isResize = tool === 'resize';
    const isWatermark = tool === 'watermark';
    const isRotate = tool === 'rotate';
    const isCrop = tool === 'crop';
    const isAdjust = tool === 'adjust';
    $('watermarkLabel').classList.toggle('hidden', !isWatermark);
    $('watermarkText').classList.toggle('hidden', !isWatermark);
    $('widthInput').parentElement.classList.toggle('hidden', !isResize);
    $('heightInput').parentElement.classList.toggle('hidden', !isResize);
    $('keepRatio').parentElement.classList.toggle('hidden', !isResize);
    $('rotateOptions').classList.toggle('hidden', !isRotate);
    $('cropOptions').classList.toggle('hidden', !isCrop);
    $('adjustOptions').classList.toggle('hidden', !isAdjust);
    $('qualityInput').classList.toggle('hidden', isWatermark);
    $('qualityInput').previousElementSibling?.classList.toggle('hidden', isWatermark);
    if ((tool === 'compress' || tool === 'convert') && $('formatSelect').value === 'image/png') $('formatSelect').value = 'image/webp';
    if (isWatermark) $('formatSelect').value = 'image/png';
  }
  ['brightness', 'contrast', 'saturation'].forEach((key) => {
    $(`${key}Input`).addEventListener('input', () => {
      $(`${key}Value`).textContent = `${$(`${key}Input`).value}%`;
      invalidateResult();
    });
  });
  ['formatSelect', 'watermarkText', 'rotateSelect', 'flipHorizontal', 'flipVertical', 'cropX', 'cropY', 'cropWidth', 'cropHeight'].forEach((id) => {
    $(id).addEventListener('input', invalidateResult);
    $(id).addEventListener('change', invalidateResult);
  });

  input.addEventListener('change', () => {
    const file = input.files?.[0];
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
      toast('Please choose a JPG, PNG or WebP image.'); input.value = ''; return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast('Please choose an image smaller than 20 MB.'); input.value = ''; return;
    }
    const nextUrl = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      processingVersion += 1;
      revoke(sourceUrl); revoke(resultUrl);
      sourceUrl = nextUrl; resultUrl = null;
      sourceImage = image; sourceFile = file;
      sourceName = file.name.replace(/\.[^.]+$/, '') || 'image';
      $('widthInput').value = image.naturalWidth;
      $('heightInput').value = image.naturalHeight;
      $('cropX').value = 0; $('cropY').value = 0;
      $('cropWidth').value = image.naturalWidth; $('cropHeight').value = image.naturalHeight;
      $('fileMeta').textContent = `${file.name} · ${image.naturalWidth} × ${image.naturalHeight} · ${formatBytes(file.size)}`;
      $('fileMeta').classList.remove('hidden');
      stage.replaceChildren();
      const preview = new Image(); preview.alt = 'Original image preview'; preview.src = sourceUrl;
      stage.appendChild(preview);
      $('previewStatus').textContent = 'Original image';
      $('resultMeta').textContent = 'Ready to process';
      processButton.disabled = false;
      download.classList.add('disabled'); download.removeAttribute('href');
      syncTool();
    };
    image.onerror = () => { revoke(nextUrl); toast('This image could not be opened.'); input.value = ''; };
    image.src = nextUrl;
  });

  function buildCanvas() {
    if (!sourceImage) throw new Error('Choose an image first.');
    const tool = $('toolSelect').value;
    let width = sourceImage.naturalWidth;
    let height = sourceImage.naturalHeight;
    let cropX = 0; let cropY = 0;
    if (tool === 'crop') {
      cropX = Number($('cropX').value); cropY = Number($('cropY').value);
      width = Number($('cropWidth').value); height = Number($('cropHeight').value);
      if (![cropX, cropY, width, height].every(Number.isInteger) || cropX < 0 || cropY < 0 || width < 1 || height < 1 || cropX + width > sourceImage.naturalWidth || cropY + height > sourceImage.naturalHeight) {
        throw new Error('Choose a crop area that stays inside the original image.');
      }
    }
    if (tool === 'resize') {
      width = Number($('widthInput').value);
      height = Number($('heightInput').value);
      if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || width > 10000 || height > 10000) {
        throw new Error('Enter a width and height from 1 to 10,000 pixels.');
      }
      if ($('keepRatio').checked) height = Math.max(1, Math.round(sourceImage.naturalHeight * width / sourceImage.naturalWidth));
    }
    const angle = tool === 'rotate' ? Number($('rotateSelect').value) : 0;
    const quarterTurn = angle === 90 || angle === 270;
    const canvas = document.createElement('canvas');
    canvas.width = quarterTurn ? height : width;
    canvas.height = quarterTurn ? width : height;
    if (canvas.width * canvas.height > 40000000) throw new Error('This image is too large to process safely in your browser. Resize it first.');
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Your browser could not start image processing.');
    if ($('formatSelect').value === 'image/jpeg') {
      context.fillStyle = '#ffffff'; context.fillRect(0, 0, canvas.width, canvas.height);
    }
    if (tool === 'adjust') {
      context.filter = `brightness(${$('brightnessInput').value}%) contrast(${$('contrastInput').value}%) saturate(${$('saturationInput').value}%)`;
    }
    if (tool === 'crop') {
      context.drawImage(sourceImage, cropX, cropY, width, height, 0, 0, width, height);
    } else if (tool === 'rotate') {
      context.translate(canvas.width / 2, canvas.height / 2);
      context.rotate(angle * Math.PI / 180);
      context.scale($('flipHorizontal').checked ? -1 : 1, $('flipVertical').checked ? -1 : 1);
      context.drawImage(sourceImage, -width / 2, -height / 2, width, height);
    } else {
      context.drawImage(sourceImage, 0, 0, width, height);
    }
    if (tool === 'watermark') {
      const text = $('watermarkText').value.trim() || '© SmartPix Studio';
      const size = Math.max(18, Math.round(width * 0.045));
      context.font = `700 ${size}px sans-serif`;
      context.textAlign = 'right'; context.textBaseline = 'bottom';
      context.lineWidth = Math.max(2, size * 0.08);
      context.strokeStyle = 'rgba(0,0,0,.55)';
      context.fillStyle = 'rgba(255,255,255,.9)';
      context.strokeText(text, width - 24, height - 22, Math.max(80, width - 48));
      context.fillText(text, width - 24, height - 22, Math.max(80, width - 48));
    }
    return canvas;
  }

  processButton.addEventListener('click', () => {
    if (!sourceImage || processButton.disabled) return;
    processButton.disabled = true;
    processButton.textContent = 'Processing…';
    const currentVersion = ++processingVersion;
    try {
      const canvas = buildCanvas();
      const mime = $('formatSelect').value;
      const quality = Number($('qualityInput').value) / 100;
      canvas.toBlob((blob) => {
        processButton.disabled = false;
        processButton.innerHTML = 'Process image <span>→</span>';
        if (currentVersion !== processingVersion) return;
        if (!blob) { toast('This format is not supported by your browser. Try JPG or PNG.'); return; }
        revoke(resultUrl);
        resultUrl = URL.createObjectURL(blob);
        stage.replaceChildren();
        const preview = new Image(); preview.alt = 'Processed image preview'; preview.src = resultUrl;
        stage.appendChild(preview);
        $('previewStatus').textContent = 'Processed successfully';
        const delta = sourceFile ? ((1 - blob.size / sourceFile.size) * 100) : null;
        const deltaLabel = delta === null ? '' : delta >= 0 ? ` · ${delta.toFixed(0)}% smaller` : ` · ${Math.abs(delta).toFixed(0)}% larger`;
        $('resultMeta').textContent = `${canvas.width} × ${canvas.height} · ${formatBytes(blob.size)}${deltaLabel}`;
        download.href = resultUrl;
        download.download = `${sourceName}-smartpix.${mime === 'image/jpeg' ? 'jpg' : mime === 'image/webp' ? 'webp' : 'png'}`;
        download.classList.remove('disabled');
        toast('Your image is ready to download.');
      }, mime, mime === 'image/png' ? undefined : quality);
    } catch (error) {
      processButton.disabled = false;
      processButton.innerHTML = 'Process image <span>→</span>';
      toast(error.message || 'Something went wrong. Please try another image.');
    }
  });


  // AI requests are sent only to same-origin server functions; provider keys never reach the browser.
  const aiMode = $('aiMode');
  const aiFileInput = $('aiImageInput');
  const aiButton = $('aiProcessBtn');
  let aiFile = null;
  let aiCapabilities = { backgroundRemoval: false, productPhotoAI: false };
  let aiBusy = false;

  function currentAICapability() {
    return aiMode.value === 'background' ? aiCapabilities.backgroundRemoval : aiCapabilities.productPhotoAI;
  }
  function clearAIResult() {
    $('aiDownloadBtn').classList.add('disabled'); $('aiDownloadBtn').removeAttribute('href');
    $('aiPreviewStage').replaceChildren();
    const empty = document.createElement('div'); empty.className = 'empty-preview';
    const icon = document.createElement('div'); icon.className = 'empty-icon'; icon.textContent = '✧';
    const title = document.createElement('b'); title.textContent = 'Your AI result will appear here';
    const note = document.createElement('span'); note.textContent = 'Choose a tool and upload an image';
    empty.append(icon, title, note); $('aiPreviewStage').appendChild(empty);
    $('aiPreviewStatus').textContent = 'No result yet';
    $('aiResultMeta').textContent = 'No new result yet';
  }
  function syncAIControls(preserveStatus = false) {
    const productMode = aiMode.value === 'product';
    $('aiPromptWrap').classList.toggle('hidden', !productMode);
    const ready = currentAICapability();
    aiButton.disabled = !ready || !aiFile || aiBusy;
    aiMode.disabled = aiBusy;
    aiFileInput.disabled = aiBusy;
    $('aiPrompt').disabled = aiBusy;
    aiButton.textContent = aiBusy ? 'Processing securely…' : !ready ? 'AI tools not configured' : productMode ? 'Create product photo' : 'Remove background';
    if (!preserveStatus) {
      if (!ready) $('aiStatus').textContent = 'The site owner must configure the relevant AI provider and enable AI processing.';
      else $('aiStatus').textContent = aiFile ? 'Ready. Your image will be sent securely to the configured AI provider.' : 'Provider connected. Choose an image to begin.';
    }
  }
  async function loadAICapabilities() {
    try {
      const response = await fetch('/api/health', { headers: { accept: 'application/json' }, cache: 'no-store' });
      if (!response.ok) throw new Error('Health check unavailable');
      const data = await response.json();
      aiCapabilities = data.capabilities || aiCapabilities;
    } catch (_) {
      aiCapabilities = { backgroundRemoval: false, productPhotoAI: false };
    }
    syncAIControls();
  }
  aiMode.addEventListener('change', () => { clearAIResult(); syncAIControls(); });
  aiFileInput.addEventListener('change', () => {
    aiFile = aiFileInput.files?.[0] || null;
    if (aiFile && !['image/png', 'image/jpeg', 'image/webp'].includes(aiFile.type)) {
      aiFile = null; aiFileInput.value = ''; $('aiFileMeta').textContent = 'Please choose a JPG, PNG or WebP image.';
    } else if (aiFile && aiFile.size > 3 * 1024 * 1024) {
      aiFile = null; aiFileInput.value = ''; $('aiFileMeta').textContent = 'AI processing accepts images up to 3 MB. Compress the image first if needed.';
    } else if (aiFile) {
      $('aiFileMeta').textContent = `${aiFile.name} · ${(aiFile.size / 1024).toFixed(0)} KB · sent to provider only when you press the AI button`;
    } else {
      $('aiFileMeta').textContent = 'AI images are sent to the configured provider for processing.';
    }
    clearAIResult();
    syncAIControls();
  });
  document.querySelectorAll('[data-ai-tool]').forEach((button) => button.addEventListener('click', () => {
    aiMode.value = button.dataset.aiTool;
    syncAIControls();
    $('ai-workspace').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }));
  aiButton.addEventListener('click', async () => {
    if (!aiFile || !currentAICapability() || aiBusy) return;
    const mode = aiMode.value;
    const prompt = $('aiPrompt').value.trim();
    if (mode === 'product' && (prompt.length < 10 || prompt.length > 600)) {
      $('aiStatus').textContent = 'Please describe the product photo edit in 10 to 600 characters.';
      return;
    }
    aiBusy = true; syncAIControls();
    $('aiPreviewStatus').textContent = 'Processing';
    $('aiStatus').textContent = 'Processing can take a little time. Keep this page open.';
    try {
      const image = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Could not read the selected image.'));
        reader.readAsDataURL(aiFile);
      });
      const token = await window.smartpixGetAccessToken?.();
      if (!token) throw new Error('Sign in to SmartPix Studio and choose an active paid plan to use AI tools.');
      const response = await fetch(mode === 'background' ? '/api/ai-background' : '/api/ai-product', {
        method: 'POST',
        headers: { 'content-type': 'application/json', accept: 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ image, prompt })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'The AI provider could not process this image.');
      if (typeof data.image !== 'string' || !data.image.startsWith('data:image/')) throw new Error('The AI provider returned an invalid image.');
      const result = new Image(); result.alt = 'AI processed image preview'; result.src = data.image;
      $('aiPreviewStage').replaceChildren(result);
      $('aiPreviewStatus').textContent = 'Completed';
      $('aiResultMeta').textContent = `${mode === 'background' ? 'Background removed' : 'Product photo edited'} · WebP`;
      $('aiDownloadBtn').href = data.image;
      const aiBaseName = aiFile.name.replace(/\.[^.]+$/, '') || 'smartpix-image';
      $('aiDownloadBtn').download = `${aiBaseName}-${mode === 'background' ? 'no-background' : 'ai-product'}.webp`;
      $('aiDownloadBtn').classList.remove('disabled');
      $('aiStatus').textContent = 'Done. Review the result before using it commercially.';
    } catch (error) {
      $('aiPreviewStatus').textContent = 'Could not complete';
      $('aiStatus').textContent = error.message || 'Something went wrong. Please try again later.';
    } finally {
      aiBusy = false; syncAIControls(true);
    }
  });
  loadAICapabilities();

  syncTool();
  window.addEventListener('pagehide', () => { revoke(sourceUrl); revoke(resultUrl); });
})();
